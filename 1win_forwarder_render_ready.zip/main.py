
from telethon import TelegramClient, events
import re
import os

# 🔧 Конфиг
api_id = int(os.getenv("API_ID"))
api_hash = os.getenv("API_HASH")
session_name = 'forwarder_session'

# 📡 Источники
source_channels = [
    '@was4r4',
    '@Vouchers1win_Mexico',
    '@Vouchers1win_India',
    '@offl1win_french',
    '@vouchers1win_nigeria',
    '@Vouchers1win_Turkey',
    '@Vouchers1win_Azerbaijan',
    '@official1win_br',
    '@official1win_spain',
    '@Vouchers1win_Uzbekistan',
    '@vouchers_1win_ukraine',
    '@Vouchers1win_Korea',
    '@vouchers1win_english'
]

# 🎯 Целевой канал
target_channel = '@Mortty1WIN'

# 🎯 Поиск ваучеров
voucher_pattern = re.compile(r'GARTI-[\w\d\-]{1,6}')
sent_vouchers = set()

# ▶️ Клиент
client = TelegramClient(session_name, api_id, api_hash)

@client.on(events.NewMessage(chats=source_channels))
async def handler(event):
    text = event.raw_text
    if not text:
        return

    matches = voucher_pattern.findall(text)
    if not matches:
        return

    for match in matches:
        if match in sent_vouchers:
            continue

        await client.send_message(target_channel, f"`{match}`", parse_mode='markdown')
        sent_vouchers.add(match)
        print(f"[✔] Отправлен ваучер: {match}")

print("⏳ Бот запущен и ждёт ваучеры...")
client.start()
client.run_until_disconnected()
